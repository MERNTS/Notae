// __mocks__/styleMock.js

// @ts-ignore
module.exports = {}
